# Цахим эрүүл мэнд инновацын төв

Center for Digital Health and Innovation (CDHI)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](#лиценз)
![CDHI 2026](https://img.shields.io/badge/CDHI-2026-teal.svg)

Цахим эрүүл мэнд инновацын төв хиймэл оюуныг өдөр тутмын ажилдаа хэрэглэх сонирхолтой эрүүл мэндийн салбарын эмч, судлаачид болон олон нийтэд зориулсан нээлттэй ур чадваруудыг энд байршууллаа.

Ур чадвар (skill) бол Claude-д тодорхой ажлыг хэрхэн хийхийг зааж өгсөн, урьдчилан бичсэн заавар. Нэг удаа суулгахад Claude тухайн ажилд хамаарах хүсэлт ирэх бүрд зааврыг өөрөө ачаалж мөрддөг. Иймээс заавраа дахин дахин бичих шаардлагагүй, үр дүн нэг жигд, найдвартай гарна. Энд байгаа ур чадвар бүр монгол хэлэнд тохируулсан, MIT лицензтэй, үнэ төлбөргүй.

## Ур чадварууд

| Ур чадвар | Юу хийдэг | Команд | Хувилбар |
|---|---|---|---|
| [Humanizer](humanizer/README.md) | Монгол бичвэрийг хүний бичсэн мэт болгож засна, зөв бичгийг шалгана | `/humanizer` | 1.4.0 |
| [Scientific Writing](scientific-writing/README.md) | Эрдэм шинжилгээний өгүүллийг англи, монгол хэлээр бичнэ, засна, хянана | `/scientific-writing` | 2.0.0 |

## Хэрхэн ашиглах

### Суулгах

Хэрэглэдэг хэрэгсэлдээ тохирох аргыг сонгоно уу. Ур чадвар бүрийг тусад нь суулгана.

| Хэрэгсэл | Суулгах арга |
|---|---|
| Claude (вэб, компьютерийн апп) | Customize цэсийг нээж, Plugins хэсгийг сонгоно. Өргөтгөл нэмэх товчийг дарж, ZIP файлыг задлахгүйгээр оруулна. |
| Claude Code | `/plugin marketplace add <github-нэр>/<репозитор>` гэж нэг удаа нэмээд `/plugin install humanizer@cdhi-skills`, `/plugin install scientific-writing@cdhi-skills` гэж суулгана. Эсвэл терминалд `unzip humanizer.zip -d ~/.claude/skills/` гэж ажиллуулна. |
| ChatGPT, Gemini, бусад чатбот | Ур чадварын `dist/` хавтсанд байгаа `humanizer-buten.md` эсвэл `scientific-writing-buten.md` файлыг ярианд хавсаргана. Байнга хэрэглэх бол Custom GPT, Gem, Project-ийн мэдлэгийн файл болгон оруулна. |
| Codex, Cursor, Gemini CLI | `npx skills add <github-нэр>/<репозитор> --skill humanizer --global --agent '*'` |

Цэсний нэр апп-ын хувилбараас хамаарч өөр байж болно.

### Хэрэглэх

Суулгасны дараа хүсэлтээ монголоор бичихэд тохирох ур чадвар өөрөө ажиллана. Командаар шууд дуудаж болно: `/humanizer`, `/scientific-writing`.

| Хүсэлтийн жишээ | Ажиллах ур чадвар |
|---|---|
| `Энэ бичвэрийг засаарай: [бичвэр]` | Humanizer |
| `Зөвхөн зөв бичгийн алдааг засаарай: [бичвэр]` | Humanizer |
| `Сургуулийн захиралд өргөдөл бичиж өг. Хүсэлт: [...]` | Humanizer |
| `Удиртгал бичиж өг. Сэдэв: [...]. Эх сурвалж: [хавсралт]` | Scientific Writing |
| `Энэ өгүүллийг рецензент шиг шалгаач, засахгүй: [бичвэр]` | Scientific Writing |
| `Ном зүйг Vancouver стандартаар засаарай: [жагсаалт]` | Scientific Writing |

## Анхаарах зүйл

- Ур чадвар нэр, тоо, огноо, эшлэл зохиохгүй. Эцсийн бичвэрийг эх сурвалжтай нь тулгаж шалгана уу.
- Хиймэл оюун ашигласан тухай сэтгүүл, байгууллагын бодлогыг мөрдөнө үү.

## Репозиторын бүтэц

```text
├── README.md                 энэ хуудас
├── .claude-plugin/           Claude Code-ийн өргөтгөлийн жагсаалт (marketplace)
├── humanizer/                Humanizer ур чадварын хавтас
├── humanizer.zip             Claude-д оруулах файл
├── scientific-writing/       Scientific Writing ур чадварын хавтас
└── scientific-writing.zip    Claude-д оруулах файл
```

## Санал, алдаа

Санал, илэрсэн алдааг репозиторын Issues хэсэгт бичнэ үү. Алдаа мэдээлэхдээ ур чадварын нэр, хувилбар, оруулсан бичвэр, гарсан хариултыг хавсаргана уу.

## Лиценз

Бүх ур чадвар [MIT лиценз](https://opensource.org/license/mit)-тэй. © 2026 Center for Digital Health and Innovation.

- Humanizer: Siqi Chen-ий [blader/humanizer](https://github.com/blader/humanizer) (© 2025) төсөлд суурилсан.
- Scientific Writing: K-Dense Inc.-ийн [scientific-writing](https://github.com/K-Dense-AI/claude-scientific-skills) (© 2025) ур чадварт суурилсан.
